package com.vidgrab.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Keeps downloads running when the app is in the background / screen is off. */
class DownloadService : Service() {

    companion object {
        const val CHANNEL = "downloads"
        private const val NID = 7
        @Volatile var isRunning = false

        fun ensure(ctx: Context) {
            if (isRunning) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (_: Exception) {
                // Android 12+ may refuse starting from background – downloads still run while the app is open
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null

    private val tick = object : Runnable {
        override fun run() {
            val m = DownloadManager
            val running = m.items.count { it.status == DlStatus.RUNNING }
            val queued = m.items.count { it.status == DlStatus.QUEUED }
            if ((running == 0 && queued == 0) || m.toolsFailed) {
                stopSelf()
                return
            }
            runCatching {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, build())
            }
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        try {
            ServiceCompat.startForeground(this, NID, build(), type)
        } catch (_: Exception) {
            isRunning = false
            stopSelf()
            return
        }
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VidGrab:downloads").apply {
                setReferenceCounted(false)
                acquire(6L * 3600_000L)
            }
        handler.postDelayed(tick, 1500)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(tick)
        runCatching { wakeLock?.release() }
        DownloadManager.saveNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun build(): android.app.Notification {
        val m = DownloadManager
        val run = m.items.filter { it.status == DlStatus.RUNNING }
        val queued = m.items.count { it.status == DlStatus.QUEUED }
        val done = m.items.count { it.status == DlStatus.COMPLETED }
        val avg = if (run.isEmpty()) 0 else run.map { it.percent }.average().toInt()
        val text = if (run.isEmpty()) "بالانتظار: $queued"
        else "عم ينزّل ${run.size} • بالانتظار $queued • مكتمل $done"
        val big = run.take(4).joinToString("\n") { "${it.percent.toInt()}%  ${it.displayTitle}" }

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("VidGrab")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (big.isEmpty()) text else "$text\n$big"))
            .setProgress(100, avg, run.isEmpty())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(pi)
            .build()
    }
}
