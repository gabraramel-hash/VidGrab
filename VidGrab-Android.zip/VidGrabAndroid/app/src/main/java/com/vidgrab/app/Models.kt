package com.vidgrab.app

import org.json.JSONObject
import java.util.UUID

enum class DlStatus(val label: String) {
    QUEUED("بالانتظار"),
    RUNNING("عم ينزّل"),
    PAUSED("موقوف مؤقتاً"),
    COMPLETED("مكتمل ✔"),
    FAILED("فشل ✖"),
    CANCELED("ملغى")
}

class DownloadItem(
    val id: String = UUID.randomUUID().toString().replace("-", ""),
    var url: String,
    var title: String,
    var quality: String,
    var subFolder: String = "",
    var filePrefix: String = "",
    var noPlaylist: Boolean = false,
    @Volatile var status: DlStatus = DlStatus.QUEUED,
    @Volatile var percent: Float = 0f,
    @Volatile var size: String = "",
    @Volatile var filePath: String? = null,
    @Volatile var error: String? = null,
    val addedAt: Long = System.currentTimeMillis()
) {
    // runtime only
    @Volatile var speed: String = ""
    @Volatile var eta: String = ""
    @Volatile var tmpFile: String? = null
    @Volatile var stopRequested: Boolean = false
    @Volatile var changed: Boolean = true

    val displayTitle: String get() = filePrefix + title

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("url", url); put("title", title); put("quality", quality)
        put("subFolder", subFolder); put("filePrefix", filePrefix); put("noPlaylist", noPlaylist)
        put("status", status.name); put("percent", percent.toDouble()); put("size", size)
        put("filePath", filePath ?: ""); put("error", error ?: ""); put("addedAt", addedAt)
    }

    companion object {
        fun fromJson(o: JSONObject): DownloadItem = DownloadItem(
            id = o.optString("id"),
            url = o.optString("url"),
            title = o.optString("title"),
            quality = o.optString("quality", Qualities.options[0]),
            subFolder = o.optString("subFolder"),
            filePrefix = o.optString("filePrefix"),
            noPlaylist = o.optBoolean("noPlaylist"),
            status = runCatching { DlStatus.valueOf(o.optString("status")) }.getOrDefault(DlStatus.QUEUED),
            percent = o.optDouble("percent", 0.0).toFloat(),
            size = o.optString("size"),
            filePath = o.optString("filePath").ifBlank { null },
            error = o.optString("error").ifBlank { null },
            addedAt = o.optLong("addedAt", System.currentTimeMillis())
        )
    }
}

object Qualities {
    val options = listOf(
        "أفضل جودة (فيديو)", "1080p", "720p", "480p", "360p", "صوت فقط MP3", "صوت فقط M4A"
    )

    /** yt-dlp options for a quality choice; value null = flag without argument */
    fun args(q: String): List<Pair<String, String?>> = when (q) {
        "1080p" -> video(1080)
        "720p" -> video(720)
        "480p" -> video(480)
        "360p" -> video(360)
        "صوت فقط MP3" -> listOf(
            "-f" to "ba/b", "-x" to null, "--audio-format" to "mp3", "--audio-quality" to "0"
        )
        "صوت فقط M4A" -> listOf(
            "-f" to "ba[ext=m4a]/ba/b", "-x" to null, "--audio-format" to "m4a"
        )
        else -> listOf(
            "-f" to "bv*+ba/b", "-S" to "res,ext:mp4:m4a", "--merge-output-format" to "mp4"
        )
    }

    private fun video(h: Int) = listOf(
        "-f" to "bv*+ba/b", "-S" to "res:$h,ext:mp4:m4a", "--merge-output-format" to "mp4"
    )
}
