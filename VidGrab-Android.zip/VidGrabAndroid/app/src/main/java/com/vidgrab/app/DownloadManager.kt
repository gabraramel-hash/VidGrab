package com.vidgrab.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** The queue: runs N yt-dlp downloads in parallel (like a torrent client), persists across restarts. */
object DownloadManager {
    lateinit var app: Context
        private set

    val items = CopyOnWriteArrayList<DownloadItem>()

    @Volatile var toolsReady = false
        private set
    @Volatile var toolsFailed = false
        private set
    @Volatile var toolsStatus = "جاري تجهيز المحرّك (أول مرة بياخد شوي)..."
        private set
    @Volatile var busyUpdating = false
        private set

    /** set whenever the list or any item changed; the UI clears it */
    @Volatile var dirty = true
    /** set when the list itself changed (add/remove) */
    @Volatile var structureVersion = 0
        private set

    @Volatile private var saveDirty = false
    private var initialized = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private val queueFile get() = File(app.filesDir, "queue.json")

    private val progressRe = Regex("\u001B\\[[0-9;]*[A-Za-z]")

    var maxConcurrent: Int
        get() = prefs.getInt("max", 3)
        set(v) {
            prefs.edit().putInt("max", v.coerceIn(1, 10)).apply()
            main.post { pump() }
        }

    var quality: String
        get() = prefs.getString("quality", Qualities.options[0]) ?: Qualities.options[0]
        set(v) = prefs.edit().putString("quality", v).apply()

    var playlist: Boolean
        get() = prefs.getBoolean("playlist", true)
        set(v) = prefs.edit().putBoolean("playlist", v).apply()

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
        load()
        scope.launch { initTools() }
        scope.launch {
            while (true) {
                delay(2000)
                if (saveDirty) { saveDirty = false; save() }
            }
        }
    }

    // ───────────── engine ─────────────
    private fun initTools() {
        try {
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
        } catch (e: Exception) {
            toolsFailed = true
            toolsStatus = "فشل تجهيز المحرّك: ${e.message}"
            touch()
            return
        }
        // YouTube changes often → keep yt-dlp fresh (once a day)
        val last = prefs.getLong("lastUpdate", 0L)
        if (System.currentTimeMillis() - last > 24L * 3600_000L) {
            toolsStatus = "عم يحدّث yt-dlp لآخر نسخة..."
            touch()
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
                prefs.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
            } catch (_: Exception) { /* offline – use bundled version */ }
        }
        toolsReady = true
        toolsStatus = "جاهز ✔   (yt-dlp ${versionSafe()})"
        touch()
        main.post { pump() }
    }

    private fun versionSafe(): String =
        runCatching { YoutubeDL.getInstance().version(app) }.getOrNull() ?: ""

    /** manual update from the menu; returns a message */
    fun updateNow(done: (String) -> Unit) {
        if (!toolsReady) { done("المحرّك لسّا عم يتجهّز، استنى شوي."); return }
        if (items.any { it.status == DlStatus.RUNNING }) { done("وقّف التنزيلات الشغّالة أول، بعدين حدّث."); return }
        busyUpdating = true
        toolsStatus = "عم يحدّث yt-dlp..."
        touch()
        scope.launch {
            val msg = try {
                val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
                prefs.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
                "تم ✔ ($st)\nالنسخة: ${versionSafe()}"
            } catch (e: Exception) {
                "فشل التحديث: ${e.message}"
            }
            busyUpdating = false
            toolsStatus = "جاهز ✔   (yt-dlp ${versionSafe()})"
            touch()
            main.post { done(msg); pump() }
        }
    }

    /** Reads a link: single video or a whole playlist (flat). Runs yt-dlp – call off the main thread. */
    fun probe(url: String): JSONObject {
        val req = YoutubeDLRequest(url)
        req.addOption("--flat-playlist")
        req.addOption("-J")
        req.addOption("--yes-playlist")
        val r = YoutubeDL.getInstance().execute(req)
        return JSONObject(r.out)
    }

    // ───────────── queue ─────────────
    fun add(list: List<DownloadItem>) {
        if (list.isEmpty()) return
        items.addAll(list)
        structureVersion++
        touch()
        pump()
    }

    fun pump() {
        if (!toolsReady || busyUpdating) return
        var running = items.count { it.status == DlStatus.RUNNING }
        val max = maxConcurrent
        for (it in items) {
            if (running >= max) break
            if (it.status == DlStatus.QUEUED) {
                start(it)
                running++
            }
        }
        if (items.any { it.status == DlStatus.RUNNING || it.status == DlStatus.QUEUED }) {
            DownloadService.ensure(app)
        }
    }

    private fun start(it: DownloadItem) {
        it.status = DlStatus.RUNNING
        it.stopRequested = false
        it.error = null
        it.speed = ""; it.eta = ""; it.tmpFile = null
        touch(it)
        scope.launch { runItem(it) }
    }

    private fun runItem(it: DownloadItem) {
        val tmp = Storage.tmpDir(app, it.id)
        try {
            if (it.stopRequested) return
            tmp.mkdirs()
            val req = YoutubeDLRequest(it.url)
            req.addOption("--newline")
            req.addOption("--progress")
            req.addOption("--no-simulate")
            req.addOption("--no-mtime")
            req.addOption("--continue")
            req.addOption("--windows-filenames")
            req.addOption("-P", tmp.absolutePath)
            req.addOption("-o", it.filePrefix.replace("%", "%%") + "%(title).120B.%(ext)s")
            req.addOption(
                "--progress-template",
                "download:[P]%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s|%(progress._total_bytes_str)s|%(progress._total_bytes_estimate_str)s"
            )
            req.addOption("--print", "before_dl:[T]%(title)s")
            req.addOption("--print", "after_move:[F]%(filepath)s")
            req.addOption(if (it.noPlaylist) "--no-playlist" else "--yes-playlist")
            for ((k, v) in Qualities.args(it.quality)) {
                if (v == null) req.addOption(k) else req.addOption(k, v)
            }

            YoutubeDL.getInstance().execute(
                req,
                processId = it.id,
                callback = { _: Float, _: Long, line: String -> parseLine(it, line) }
            )

            if (it.stopRequested) return

            // move finished file(s) from the private temp folder to Download/VidGrab
            val files = tmp.listFiles()?.filter {
                f -> f.isFile && !f.name.endsWith(".part") && !f.name.endsWith(".ytdl") &&
                    !f.name.contains(".part-Frag") && !f.name.endsWith(".temp")
            }.orEmpty()
            if (files.isEmpty()) throw Exception("خلص التنزيل بس ما لقيت الملف")
            var last: File? = null
            for (f in files.sortedBy { f -> f.name }) last = Storage.moveToPublic(app, f, it.subFolder)
            it.filePath = last?.absolutePath
            tmp.deleteRecursively()

            it.status = DlStatus.COMPLETED
            it.percent = 100f
            it.error = null
        } catch (e: Throwable) {
            if (!it.stopRequested) {
                it.status = DlStatus.FAILED
                it.error = cleanError(e.message)
            }
        } finally {
            it.speed = ""; it.eta = ""
            if (it.status == DlStatus.CANCELED) runCatching { tmp.deleteRecursively() }
            touch(it)
            main.post { pump() }
        }
    }

    private fun parseLine(it: DownloadItem, raw: String) {
        val line = progressRe.replace(raw, "").trim()
        when {
            line.startsWith("[P]") -> {
                val p = line.substring(3).split('|')
                if (p.size >= 5) {
                    p[0].trim().trimEnd('%').trim().toFloatOrNull()?.let { v -> it.percent = v }
                    it.speed = clean(p[1])
                    it.eta = clean(p[2])
                    var size = clean(p[3])
                    if (size.isEmpty() && clean(p[4]).isNotEmpty()) size = "~" + clean(p[4])
                    if (size.isNotEmpty()) it.size = size
                }
            }
            line.startsWith("[T]") -> it.title = line.substring(3)
            line.startsWith("[F]") -> it.tmpFile = line.substring(3)
            else -> return
        }
        touch(it)
    }

    private fun clean(s: String): String {
        val t = s.trim()
        return if (t == "NA" || t == "N/A" || t == "Unknown" || t == "None") "" else t
    }

    private fun cleanError(msg: String?): String {
        if (msg.isNullOrBlank()) return "صار خطأ غير معروف"
        val lines = progressRe.replace(msg, "").lines().map { it.trim() }.filter { it.isNotEmpty() }
        val err = lines.lastOrNull { it.contains("ERROR") } ?: lines.lastOrNull() ?: msg
        return if (err.length > 600) err.substring(0, 600) else err
    }

    // ───────────── actions ─────────────
    fun resume(it: DownloadItem) {
        if (it.status == DlStatus.PAUSED || it.status == DlStatus.FAILED || it.status == DlStatus.CANCELED) {
            it.status = DlStatus.QUEUED
            it.error = null
            touch(it)
        }
        pump()
    }

    fun pause(it: DownloadItem) {
        when (it.status) {
            DlStatus.RUNNING -> {
                it.stopRequested = true
                it.status = DlStatus.PAUSED
                kill(it)
            }
            DlStatus.QUEUED -> it.status = DlStatus.PAUSED
            else -> {}
        }
        touch(it)
    }

    fun cancel(it: DownloadItem) {
        when (it.status) {
            DlStatus.RUNNING -> {
                it.stopRequested = true
                it.status = DlStatus.CANCELED
                kill(it)
            }
            DlStatus.QUEUED, DlStatus.PAUSED, DlStatus.FAILED -> {
                it.status = DlStatus.CANCELED
                scope.launch { runCatching { Storage.tmpDir(app, it.id).deleteRecursively() } }
            }
            else -> {}
        }
        touch(it)
    }

    fun retry(it: DownloadItem) {
        if (it.status == DlStatus.RUNNING) return
        scope.launch {
            runCatching { Storage.tmpDir(app, it.id).deleteRecursively() }
            it.percent = 0f
            it.size = ""
            it.filePath = null
            it.status = DlStatus.QUEUED
            it.error = null
            touch(it)
            main.post { pump() }
        }
    }

    fun remove(it: DownloadItem) {
        if (it.status == DlStatus.RUNNING || it.status == DlStatus.QUEUED || it.status == DlStatus.PAUSED) cancel(it)
        items.remove(it)
        structureVersion++
        touch()
        pump()
    }

    fun resumeAll() { items.forEach { resume(it) } }
    fun pauseAll() { items.forEach { pause(it) } }

    fun clearCompleted() {
        items.removeIf { it.status == DlStatus.COMPLETED || it.status == DlStatus.CANCELED }
        structureVersion++
        touch()
    }

    private fun kill(it: DownloadItem) {
        runCatching { YoutubeDL.getInstance().destroyProcessById(it.id) }
    }

    private fun touch(it: DownloadItem? = null) {
        it?.changed = true
        dirty = true
        saveDirty = true
    }

    // ───────────── persistence ─────────────
    @Synchronized private fun save() {
        try {
            val arr = JSONArray()
            for (it in items) arr.put(it.toJson())
            val tmp = File(queueFile.path + ".tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(queueFile)
        } catch (_: Exception) { }
    }

    private fun load() {
        try {
            if (!queueFile.exists()) return
            val arr = JSONArray(queueFile.readText())
            for (i in 0 until arr.length()) {
                val it = DownloadItem.fromJson(arr.getJSONObject(i))
                if (it.status == DlStatus.RUNNING) it.status = DlStatus.QUEUED // continue where it stopped
                items.add(it)
            }
        } catch (_: Exception) { }
    }

    fun saveNow() { scope.launch { save() } }
}
