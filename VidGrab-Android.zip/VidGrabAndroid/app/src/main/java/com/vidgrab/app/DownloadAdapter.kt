package com.vidgrab.app

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class DownloadAdapter(private val onClick: (DownloadItem) -> Unit) :
    RecyclerView.Adapter<DownloadAdapter.VH>() {

    private var list: List<DownloadItem> = emptyList()
    private var version = -1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvTitle)
        val status: TextView = v.findViewById(R.id.tvItemStatus)
        val percent: TextView = v.findViewById(R.id.tvPercent)
        val pb: ProgressBar = v.findViewById(R.id.pb)
        val details: TextView = v.findViewById(R.id.tvDetails)
        val defaultColor: ColorStateList = status.textColors
    }

    /** Called from the UI timer. */
    fun refresh() {
        val m = DownloadManager
        if (m.structureVersion != version || list.size != m.items.size) {
            version = m.structureVersion
            list = m.items.toList()
            list.forEach { it.changed = false }
            notifyDataSetChanged()
        } else {
            for (i in list.indices) {
                if (list[i].changed) {
                    list[i].changed = false
                    notifyItemChanged(i)
                }
            }
        }
    }

    override fun getItemCount() = list.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val it = list[position]
        val ctx = h.itemView.context
        h.title.text = it.displayTitle
        h.status.text = "${it.status.label}   •   ${it.quality}"
        h.percent.text = if (it.percent > 0f) String.format(java.util.Locale.US, "%.1f%%", it.percent) else ""
        h.pb.progress = (it.percent * 10).toInt().coerceIn(0, 1000)

        val parts = mutableListOf<String>()
        if (it.size.isNotEmpty()) parts += it.size
        if (it.status == DlStatus.RUNNING) {
            if (it.speed.isNotEmpty()) parts += it.speed
            if (it.eta.isNotEmpty()) parts += "باقي ${it.eta}"
        }
        if (it.status == DlStatus.FAILED && !it.error.isNullOrEmpty()) parts += it.error!!
        if (it.status == DlStatus.COMPLETED && it.filePath != null) parts += "اكبس لتفتح الملف"
        h.details.text = parts.joinToString("   •   ")
        h.details.maxLines = if (it.status == DlStatus.FAILED) 3 else 1

        val colorRes = when (it.status) {
            DlStatus.RUNNING -> R.color.st_running
            DlStatus.COMPLETED -> R.color.st_done
            DlStatus.FAILED -> R.color.st_fail
            DlStatus.PAUSED, DlStatus.CANCELED -> R.color.st_gray
            else -> 0
        }
        if (colorRes == 0) {
            h.status.setTextColor(h.defaultColor)
        } else {
            val c = ContextCompat.getColor(ctx, colorRes)
            h.status.setTextColor(c)
            h.pb.progressTintList = ColorStateList.valueOf(c)
        }
        if (colorRes == 0) h.pb.progressTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.brand))

        h.itemView.setOnClickListener { _ -> onClick(it) }
    }
}
