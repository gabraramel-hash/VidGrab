package com.vidgrab.app

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import java.io.File

object Storage {
    /** Public folder: Download/VidGrab */
    fun publicRoot(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "VidGrab")

    /** Fallback if the public folder can't be written */
    fun privateRoot(ctx: Context): File =
        File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir, "VidGrab")

    fun tmpDir(ctx: Context, id: String): File = File(ctx.filesDir, "tmp/$id")

    fun safeName(s: String?, max: Int = 80): String {
        var r = (s ?: "").replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trimEnd('.')
        if (r.isBlank()) r = "Playlist"
        return if (r.length > max) r.substring(0, max) else r
    }

    /** Copies a finished file from the temp dir into Download/VidGrab[/sub] and deletes the source. */
    fun moveToPublic(ctx: Context, src: File, sub: String): File {
        val dest = try {
            copyInto(src, if (sub.isBlank()) publicRoot() else File(publicRoot(), sub))
        } catch (e: Exception) {
            copyInto(src, if (sub.isBlank()) privateRoot(ctx) else File(privateRoot(ctx), sub))
        }
        src.delete()
        runCatching { MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), null, null) }
        return dest
    }

    private fun copyInto(src: File, dir: File): File {
        dir.mkdirs()
        if (!dir.isDirectory) throw Exception("ما قدرت اعمل المجلد ${dir.absolutePath}")
        var dest = File(dir, src.name)
        var n = 1
        while (dest.exists()) {
            dest = File(dir, "${src.nameWithoutExtension} ($n).${src.extension}")
            n++
        }
        try {
            src.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
        return dest
    }
}
