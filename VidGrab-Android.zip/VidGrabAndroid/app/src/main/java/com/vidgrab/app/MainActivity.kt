package com.vidgrab.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {

    private lateinit var etUrls: EditText
    private lateinit var spQuality: Spinner
    private lateinit var cbPlaylist: CheckBox
    private lateinit var tvParallel: TextView
    private lateinit var btnAdd: MaterialButton
    private lateinit var tvStatus: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var adapter: DownloadAdapter

    private val m = DownloadManager
    private val handler = Handler(Looper.getMainLooper())
    private var adding = false
    private var addStatus: String? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val urlRe = Regex("https?://[^\\s<>\"']+")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        etUrls = findViewById(R.id.etUrls)
        spQuality = findViewById(R.id.spQuality)
        cbPlaylist = findViewById(R.id.cbPlaylist)
        tvParallel = findViewById(R.id.tvParallel)
        btnAdd = findViewById(R.id.btnAdd)
        tvStatus = findViewById(R.id.tvStatus)
        tvStats = findViewById(R.id.tvStats)
        tvEmpty = findViewById(R.id.tvEmpty)

        spQuality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Qualities.options)
        spQuality.setSelection(Qualities.options.indexOf(m.quality).coerceAtLeast(0))
        cbPlaylist.isChecked = m.playlist
        tvParallel.text = m.maxConcurrent.toString()

        findViewById<MaterialButton>(R.id.btnMinus).setOnClickListener { changeParallel(-1) }
        findViewById<MaterialButton>(R.id.btnPlus).setOnClickListener { changeParallel(+1) }
        findViewById<MaterialButton>(R.id.btnPaste).setOnClickListener { pasteClipboard() }
        btnAdd.setOnClickListener { onAdd() }

        val rv = findViewById<RecyclerView>(R.id.rv)
        rv.layoutManager = LinearLayoutManager(this)
        (rv.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
        adapter = DownloadAdapter { showItemActions(it) }
        rv.adapter = adapter

        askPermissions()
        handleShare(intent)
        handler.post(tick)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (m.dirty) {
                m.dirty = false
                adapter.refresh()
                updateStats()
            }
            btnAdd.isEnabled = m.toolsReady && !adding
            tvStatus.text = addStatus ?: m.toolsStatus
            handler.postDelayed(this, 500)
        }
    }

    private fun updateStats() {
        val all = m.items
        val run = all.count { it.status == DlStatus.RUNNING }
        val q = all.count { it.status == DlStatus.QUEUED }
        val done = all.count { it.status == DlStatus.COMPLETED }
        val fail = all.count { it.status == DlStatus.FAILED }
        tvStats.text = if (all.isEmpty()) "" else
            "شغّال: $run   بالانتظار: $q   مكتمل: $done   فشل: $fail   المجموع: ${all.size}"
        tvEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    // ───────────── input ─────────────
    private fun changeParallel(d: Int) {
        val v = (m.maxConcurrent + d).coerceIn(1, 10)
        m.maxConcurrent = v
        tvParallel.text = v.toString()
    }

    private fun pasteClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) { toast("الحافظة فاضية"); return }
        appendUrls(t)
    }

    private fun appendUrls(text: String) {
        val found = urlRe.findAll(text).map { it.value }.toList()
        val add = if (found.isEmpty()) text.trim() else found.joinToString("\n")
        val cur = etUrls.text?.toString()?.trim().orEmpty()
        etUrls.setText(if (cur.isEmpty()) add else "$cur\n$add")
        etUrls.setSelection(etUrls.text?.length ?: 0)
    }

    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        appendUrls(t)
        setIntent(Intent(this, MainActivity::class.java))
        toast("انحط الرابط — اختار الجودة واكبس «ضيف ونزّل»")
    }

    private fun onAdd() {
        val urls = urlRe.findAll(etUrls.text?.toString().orEmpty())
            .map { it.value.trimEnd(')', ']', '.', ',', '،') }
            .distinct().toList()
        if (urls.isEmpty()) { toast("حط لينك صحيح (لازم يبلّش بـ http)"); return }

        val q = spQuality.selectedItem?.toString() ?: Qualities.options[0]
        val whole = cbPlaylist.isChecked
        m.quality = q
        m.playlist = whole

        adding = true
        btnAdd.isEnabled = false
        lifecycleScope.launch {
            var added = 0
            try {
                for ((n, u) in urls.withIndex()) {
                    addStatus = "عم يقرا الرابط ${n + 1}/${urls.size}..."
                    added += if (whole) addWithPlaylist(u, q) else {
                        m.add(listOf(DownloadItem(url = u, title = u, quality = q, noPlaylist = true)))
                        1
                    }
                }
            } finally {
                adding = false
                addStatus = null
            }
            etUrls.setText("")
            toast(if (added > 0) "انضاف $added تنزيل ✔" else "ما انضاف شي")
        }
    }

    private suspend fun addWithPlaylist(url: String, q: String): Int {
        val json: JSONObject? = try {
            withContext(Dispatchers.IO) { m.probe(url) }
        } catch (e: Exception) {
            null
        }
        if (json == null) {
            // let yt-dlp try directly; the real error appears on the item if it fails
            m.add(listOf(DownloadItem(url = url, title = url, quality = q)))
            return 1
        }

        val entries = json.optJSONArray("entries")
        if (json.str("_type") == "playlist" && entries != null) {
            val plTitle = json.str("title") ?: "Playlist"
            val n = entries.length()
            if (n == 0) { toast("القائمة فاضية: $plTitle"); return 0 }
            val sub = Storage.safeName(plTitle)
            val ok = confirm(
                "قائمة تشغيل",
                "لقيت «$plTitle» وفيها $n فيديو.\nنزّلهن كلهن؟\n\nرح ينحطّوا بـ:\nDownload/VidGrab/$sub"
            )
            if (!ok) return 0

            val digits = maxOf(2, n.toString().length)
            val list = ArrayList<DownloadItem>()
            for (i in 0 until n) {
                val e = entries.optJSONObject(i) ?: continue
                var eu = e.str("url") ?: e.str("webpage_url")
                val id = e.str("id")
                if ((eu == null || !eu.startsWith("http")) && id != null &&
                    (e.str("ie_key") ?: "").startsWith("Youtube", ignoreCase = true)
                ) eu = "https://www.youtube.com/watch?v=$id"
                if (eu == null || !eu.startsWith("http")) continue
                list += DownloadItem(
                    url = eu,
                    title = e.str("title") ?: eu,
                    quality = q,
                    subFolder = sub,
                    filePrefix = (i + 1).toString().padStart(digits, '0') + " - ",
                    noPlaylist = true
                )
            }
            m.add(list)
            return list.size
        }

        m.add(listOf(DownloadItem(url = url, title = json.str("title") ?: url, quality = q, noPlaylist = true)))
        return 1
    }

    private fun JSONObject.str(k: String): String? =
        if (isNull(k)) null else optString(k).takeIf { it.isNotBlank() }

    private suspend fun confirm(title: String, msg: String): Boolean =
        suspendCancellableCoroutine { cont ->
            var done = false
            fun finish(v: Boolean) { if (!done) { done = true; if (cont.isActive) cont.resume(v) } }
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("إيه نزّلهن") { _, _ -> finish(true) }
                .setNegativeButton("لا") { _, _ -> finish(false) }
                .setOnDismissListener { finish(false) }
                .show()
        }

    // ───────────── item actions ─────────────
    private fun showItemActions(it: DownloadItem) {
        val acts = ArrayList<Pair<String, () -> Unit>>()
        when (it.status) {
            DlStatus.RUNNING -> {
                acts += "⏸ إيقاف مؤقت" to { m.pause(it) }
                acts += "✖ إلغاء" to { m.cancel(it) }
            }
            DlStatus.QUEUED -> {
                acts += "⏸ إيقاف مؤقت" to { m.pause(it) }
                acts += "✖ إلغاء" to { m.cancel(it) }
            }
            DlStatus.PAUSED -> {
                acts += "▶ استكمال" to { m.resume(it) }
                acts += "✖ إلغاء" to { m.cancel(it) }
            }
            DlStatus.FAILED, DlStatus.CANCELED -> {
                acts += "▶ جرّب مرة تانية" to { m.resume(it) }
                acts += "↻ إعادة من الأول" to { m.retry(it) }
            }
            DlStatus.COMPLETED -> {
                acts += "🎬 فتح الملف" to { openFile(it) }
                acts += "📤 مشاركة" to { shareFile(it) }
                acts += "↻ نزّلو مرة تانية" to { m.retry(it) }
            }
        }
        if (!it.error.isNullOrEmpty()) acts += "ℹ عرض الخطأ" to {
            MaterialAlertDialogBuilder(this).setTitle("الخطأ").setMessage(it.error)
                .setPositiveButton("تمام", null).show()
            Unit
        }
        acts += "🔗 نسخ الرابط" to {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("url", it.url))
            toast("انتسخ الرابط")
        }
        acts += "🗑 حذف من القائمة" to { m.remove(it) }

        MaterialAlertDialogBuilder(this)
            .setTitle(it.displayTitle)
            .setItems(acts.map { a -> a.first }.toTypedArray()) { _, w -> acts[w].second() }
            .show()
    }

    private fun fileUri(it: DownloadItem) = it.filePath?.let { p ->
        val f = File(p)
        if (!f.exists()) null else FileProvider.getUriForFile(this, "$packageName.files", f)
    }

    private fun mime(path: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(File(path).extension.lowercase()) ?: "video/*"

    private fun openFile(it: DownloadItem) {
        val uri = try { fileUri(it) } catch (e: Exception) { null }
        if (uri == null) { toast("الملف مش موجود (يمكن انحذف أو انتقل)"); return }
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(it.filePath!!))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) } catch (e: ActivityNotFoundException) { toast("ما في برنامج بيفتح هالنوع") }
    }

    private fun shareFile(it: DownloadItem) {
        val uri = try { fileUri(it) } catch (e: Exception) { null }
        if (uri == null) { toast("الملف مش موجود"); return }
        val i = Intent(Intent.ACTION_SEND).setType(mime(it.filePath!!))
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "مشاركة"))
    }

    // ───────────── menu ─────────────
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.m_resume_all -> m.resumeAll()
            R.id.m_pause_all -> m.pauseAll()
            R.id.m_clear_done -> m.clearCompleted()
            R.id.m_update -> m.updateNow { msg ->
                MaterialAlertDialogBuilder(this).setTitle("تحديث yt-dlp").setMessage(msg)
                    .setPositiveButton("تمام", null).show()
            }
            R.id.m_where -> MaterialAlertDialogBuilder(this)
                .setTitle("وين بينحفظوا؟")
                .setMessage(
                    "الفيديوهات بتنحفظ بـ:\n${Storage.publicRoot().absolutePath}\n\n" +
                        "يعني بمجلد Download ← VidGrab. كل مسلسل/قائمة بمجلد لحالو.\n" +
                        "بتلاقيهن كمان بالمعرض (Gallery) وبمدير الملفات."
                )
                .setPositiveButton("تمام", null).show()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ───────────── misc ─────────────
    private fun askPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT <= 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
